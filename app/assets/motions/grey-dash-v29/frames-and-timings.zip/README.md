# 灰套装闪身步拆帧

使用用户提供的“仅修字母笔画、先右后左”GIF。

frame-01.png 至 frame-08.png 为向右，frame-09.png 至 frame-16.png 为向左。全部PNG保持原始437×439像素，未重绘、未缩放。

原图 original.gif 每帧150毫秒。默认加速版 faster-recovery.gif 只修改GIF的帧时长字段，画面不重编码。两段各自第6、7帧分别80、60毫秒，其余150毫秒；每方向1040毫秒。

修改 timings.json 中 durations 数组可定义16帧各自的停留毫秒数。GIF精度为10毫秒。最后一帧站稳仍保留150毫秒。
